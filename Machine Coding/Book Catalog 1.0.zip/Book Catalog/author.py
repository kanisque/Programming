class Author:
    def __init__(self,authorId,name,phoneNumber,birthDate,deathDate):
        self.authorId = authorId
        self.name = name
        self.phoneNumber = phoneNumber
        self.birthDate = birthDate
        self.deathDate = deathDate
